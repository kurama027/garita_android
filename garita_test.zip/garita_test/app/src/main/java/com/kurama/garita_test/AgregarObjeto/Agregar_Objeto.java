package com.kurama.garita_test.AgregarObjeto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kurama.garita_test.R;

public class Agregar_Objeto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_objeto);
    }
}