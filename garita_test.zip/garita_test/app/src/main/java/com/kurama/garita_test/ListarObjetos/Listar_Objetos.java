package com.kurama.garita_test.ListarObjetos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kurama.garita_test.R;

public class Listar_Objetos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_objetos);
    }
}