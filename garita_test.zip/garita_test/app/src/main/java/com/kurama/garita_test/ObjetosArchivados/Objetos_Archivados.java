package com.kurama.garita_test.ObjetosArchivados;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kurama.garita_test.R;

public class Objetos_Archivados extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objetos_archivados);
    }
}